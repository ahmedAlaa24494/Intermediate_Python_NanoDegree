"""Init file for MemeEngine Modules."""
from .MemeGenerator import MemeGenerator